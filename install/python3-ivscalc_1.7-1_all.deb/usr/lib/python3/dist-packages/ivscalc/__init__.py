#!/usr/bin/env python
# -*- coding: utf-8 -*-

##
# @package ivscalc
# Main ivscalc module.
